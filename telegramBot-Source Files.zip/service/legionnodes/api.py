import time

from aiohttp import ClientSession, ClientResponse

from loguru import logger


class LegionNodes:
    def __init__(self, caching_time=0):
        self.session = ClientSession()
        self.cache = {'caching_time': caching_time, 'last_data': 0, 'data': None}

    async def get_apr(self):
        return await (await self.session.get('https://api.maplenodes.com/evmos/apr/')).json()

    async def evmos_stacking(self, amount):
        if self.cache['last_data'] < time.time() or self.cache['data'] is None:
            self.cache['data'] = await self.get_apr()
            self.cache['last_data'] = int(time.time()) + self.cache['caching_time']
        return ((self.cache['data']['evmos_apr'] / 100) * amount) / 365

    def evmos_usd(self, amount):
        return self.cache['data']['evmos_usd'] * amount
