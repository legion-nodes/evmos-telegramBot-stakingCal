from tortoise import Tortoise
from data.config import Mysql

db_url = f'mysql://{Mysql.user}:{Mysql.password}@{Mysql.host}:{Mysql.port}/{Mysql.database}'
modules = {'models': ['database.models']}


async def initialize(*_, **__):
    await Tortoise.init(
        db_url=db_url,
        modules=modules
    )
    await Tortoise.generate_schemas()
