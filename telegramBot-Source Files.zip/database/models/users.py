from tortoise import Model
from tortoise import fields
from .dataclasses import UserType


class User(Model):
    id = fields.IntField(pk=True)
    chat_id = fields.BigIntField(unique=True)

    type = fields.SmallIntField(default=UserType.user, validators=[UserType.validator])

    full_name = fields.CharField(max_length=130)
    username = fields.CharField(max_length=32, null=True)

    register_time = fields.DatetimeField(auto_now=True)

    class Meta:
        table = 'users'

    @property
    def is_admin(self) -> bool:
        return self.type == UserType.admin
