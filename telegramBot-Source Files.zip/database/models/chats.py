from tortoise import Model
from tortoise import fields


class Chat(Model):
    id = fields.IntField(pk=True)
    chat_id = fields.BigIntField(unique=True)
    title = fields.CharField(max_length=255)
    add_time = fields.DatetimeField(auto_now=True)

    class Meta:
        table = 'chats'
