from tortoise.exceptions import ValidationError


class UserType:
    user = 0
    admin = 1

    __all_values = [user, admin]

    @classmethod
    def validator(cls, value: int):
        if value not in cls.__all_values:
            raise ValidationError(f"{cls.__name__}: [{value}] not in {cls.__all_values}")
