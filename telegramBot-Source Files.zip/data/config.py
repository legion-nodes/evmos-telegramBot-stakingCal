from configparser import ConfigParser
from dataclasses import dataclass

parser = ConfigParser()
parser.read('config.ini')


@dataclass
class Telegram:
    section = 'telegram'
    # params
    token = parser.get(section, 'token')


@dataclass
class Mysql:
    section = 'mysql'
    # params
    host = parser.get(section, 'host')
    port = int(parser.get(section, 'port'))
    user = parser.get(section, 'user')
    password = parser.get(section, 'password')
    database = parser.get(section, 'database')
