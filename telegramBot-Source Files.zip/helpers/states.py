from aiogram.dispatcher.filters.state import StatesGroup, State


class Enter_evmos(StatesGroup):
    enter_evmos = State()
