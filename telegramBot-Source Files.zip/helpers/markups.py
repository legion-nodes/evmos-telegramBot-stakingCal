from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton


def base_markup():
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add('💎 STAKING CALCULATOR')
    return markup


def cancel_markup():
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(KeyboardButton('⤵️ Go back'))
    return markup


def legion_nodes_markup():
    markup = InlineKeyboardMarkup()
    markup.add(InlineKeyboardButton('〽️ Legion Nodes ', url='https://legionnodes.com/#stakingCalculator'))
    return markup
