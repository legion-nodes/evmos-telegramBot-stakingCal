from aiogram import executor, Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.redis import RedisStorage2

from loguru import logger

import database
import utils
from data import config
from filters import register_filters
from handlers import register_handlers
from middlewares import register_middlewares


async def on_startup(dp: Dispatcher):
    register_middlewares(dp)
    register_filters(dp)
    register_handlers(dp)

    await database.initialize()

    utils.init(dp.bot.data)


async def on_shutdown(dp: Dispatcher):
    await utils.close(dp.bot.data)

    await dp.storage.close()
    await dp.storage.wait_closed()


if __name__ == "__main__":
    try:
        bot = Bot(token=config.Telegram.token, parse_mode=types.ParseMode.HTML)
        # storage = RedisStorage2(host='localhost', port=55001, password='redispw')
        storage = RedisStorage2()
        dp = Dispatcher(bot, storage=storage)

        executor.start_polling(
            dp,
            on_startup=on_startup,
            on_shutdown=on_shutdown
        )
    except (KeyboardInterrupt, SystemExit):
        logger.error("Bot stopped!")
