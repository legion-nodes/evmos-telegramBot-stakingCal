from typing import Dict, Any

from . import logging


def init(data: Dict[str, Any]):
    logging.init()


async def close(data: Dict[str, Any]):
    # data['wrapper'].close()
    pass
