import typing
import warnings

from aiogram.dispatcher.filters import BoundFilter
from aiogram.types import Message, CallbackQuery, ChatMemberUpdated
from database.models import User


class UserTypeFilter(BoundFilter):
    key = 'user_type'

    def __init__(self, user_type: typing.Union[int, list, set]):
        if isinstance(user_type, int):
            user_type = {user_type}
        else:
            user_type = set(user_type)
        self.chat_type: typing.Set[int] = user_type

    async def check(self, obj: typing.Union[Message, CallbackQuery, ChatMemberUpdated]):
        if isinstance(obj, Message) or isinstance(obj, ChatMemberUpdated):
            chat_id = (obj.from_user if obj.from_user is not None else obj.chat).id
        elif isinstance(obj, CallbackQuery):
            chat_id = (obj.from_user if obj.from_user is not None else obj.message.chat).id
        else:
            warnings.warn("ChatTypeFilter doesn't support %s as input", type(obj))
            return False

        user = await User.get(chat_id=chat_id)
        return user.type in self.chat_type
