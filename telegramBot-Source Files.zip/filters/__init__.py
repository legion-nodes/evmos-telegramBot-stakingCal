from aiogram import Dispatcher
from loguru import logger

from .changes import IsChangesFilter
from .usertype import UserTypeFilter


def register_filters(dp: Dispatcher):
    logger.info("Configure filters...")
    for _filter in [IsChangesFilter, UserTypeFilter]:
        dp.filters_factory.bind(_filter)
