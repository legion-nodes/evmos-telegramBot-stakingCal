import typing
import warnings

from dataclasses import dataclass

from aiogram.dispatcher.filters import BoundFilter
from aiogram.types import ChatMemberUpdated, CallbackQuery, Message

from database.models import User
from database.models import Chat


@dataclass
class IsChangesFilter(BoundFilter):
    key = 'is_changed'
    required = True

    def __init__(self, is_changed):
        self.is_changed = is_changed

    async def check(self, obj: typing.Union[Message, CallbackQuery, ChatMemberUpdated]) -> bool:
        user = await User.get_or_none(
            chat_id=obj.from_user.id
        )

        if user is None:
            await User.create(
                chat_id=obj.from_user.id,
                full_name=obj.from_user.full_name,
                username=obj.from_user.username,
            )
        else:
            if user.full_name != obj.from_user.full_name or user.username != obj.from_user.username:
                user.full_name = obj.from_user.full_name
                user.username = obj.from_user.username
                await user.save()

        if obj.chat.type in ['group', 'supergroup']:
            chat = await Chat.get_or_none(
                chat_id=obj.chat.id
            )

            if chat is None:
                await Chat.create(
                    chat_id=obj.chat.id,
                    title=obj.chat.title
                )
            else:
                if chat.title != obj.chat.title:
                    chat.title = obj.chat.title
                    await chat.save()

        return True
