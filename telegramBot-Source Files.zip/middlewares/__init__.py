from aiogram import Dispatcher
from aiogram.contrib.middlewares.logging import LoggingMiddleware
from loguru import logger


def register_middlewares(dp: Dispatcher):
    logger.info("Configure middlewares...")
    dp.middleware.setup(LoggingMiddleware("data"))
