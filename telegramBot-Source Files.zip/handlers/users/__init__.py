from aiogram import Dispatcher

from .base import register_base_handlers


def register_users_handlers(dp: Dispatcher):
    register_base_handlers(dp)
