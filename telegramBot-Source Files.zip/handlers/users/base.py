from aiogram import types, Dispatcher
from aiogram.dispatcher import FSMContext
from aiogram.types import ChatType
from aiogram.utils.markdown import quote_html

from service.legionnodes.api import LegionNodes
from helpers.markups import base_markup, cancel_markup, legion_nodes_markup
from helpers.states import Enter_evmos

import asyncio


legionnodes = LegionNodes(30)


async def start_command(message: types.Message, state: FSMContext):
    await state.reset_state()

    await message.answer(
        f'👋 Welcome, {quote_html(message.from_user.full_name)}!',
        reply_markup=base_markup()
    )


async def cancel_command(message: types.Message, state: FSMContext):
    await state.reset_state()
    await message.answer(
        f'👋 Welcome, {quote_html(message.from_user.full_name)}!',
        reply_markup=base_markup()
    )


async def getting_evmos_stacking(message: types.Message):
    await message.answer('✍️ Enter Amount of Evmos', reply_markup=cancel_markup())
    await Enter_evmos.enter_evmos.set()


async def getting_evmos_stacking_state(message: types.Message, state: FSMContext):
    try:
        amount = float(message.text)
    except:
        await message.reply('🙅‍♂️ You dont\'t specify a number. Try again and re-specify Amount of Evmos',
                            reply_markup=cancel_markup())
        return

    _message = await message.reply("⏳ Process...")
    result = await legionnodes.evmos_stacking(amount)
    evmos_usd = legionnodes.evmos_usd(result)


    await _message.edit_text(f"<b>Estimated daily rewards:</> <code>{result:.2f} evmos (${evmos_usd:.2f})</>", reply_markup=legion_nodes_markup())
    await message.answer("Powered By Legion Nodes", reply_markup=base_markup())
    await state.finish()


async def getting_evmos_in_chat(message: types.Message):
    args = message.get_args()
    if len(args) == 0:
        _message = await message.reply('🙅‍♂️ You didn\'t specify an amount\n'
                            'Example: <code>/cal 100</>')

        await asyncio.sleep(20)
        await _message.delete()

        try:
            await message.delete()
        except:
            pass
      


    else:
        try:
            amount = float(args)
        except:
            _message = await message.reply('🙅‍♂️ You didn\'t specify an amount\n'
                                'Example: <code>/cal 100</>')
        
            await asyncio.sleep(20)
            await _message.delete()
            
            try:
                await message.delete()
            except:
                pass

            return

        result = await legionnodes.evmos_stacking(amount)
        evmos_usd = legionnodes.evmos_usd(result)
        _message = await message.reply(f"<b>Estimated daily rewards:</> <code>{result:.2f} evmos (${evmos_usd:.2f})</>", reply_markup=legion_nodes_markup())

        await asyncio.sleep(20)
        await _message.delete()

        try:
            await message.delete()
        except:
            pass

def register_base_handlers(dp: Dispatcher):
    # Default filters in all handlers
    defaults = {'state': '*'}

    dp.register_message_handler(start_command, commands='start', chat_type=ChatType.PRIVATE, **defaults)  # /start
    dp.register_message_handler(getting_evmos_stacking, text='💎 STAKING CALCULATOR', chat_type=ChatType.PRIVATE, **defaults)  # /get_evmos
    dp.register_message_handler(getting_evmos_stacking_state, state=Enter_evmos.enter_evmos, chat_type=ChatType.PRIVATE)  # /get_evmos
    dp.register_message_handler(cancel_command, text='⤵️ Go back', chat_type=ChatType.PRIVATE, **defaults)  # /cancel
    dp.register_message_handler(getting_evmos_in_chat, commands='cal', chat_type=[ChatType.GROUP, ChatType.SUPERGROUP])  # /get_evmos
