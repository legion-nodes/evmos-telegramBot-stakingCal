from aiogram import Dispatcher
from loguru import logger

from .admins import register_admins_handlers
from .users import register_users_handlers


def register_handlers(dp: Dispatcher):
    logger.info("Configure handlers...")
    register_admins_handlers(dp)
    register_users_handlers(dp)
