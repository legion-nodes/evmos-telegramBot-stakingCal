from aiogram import Dispatcher

from .base import register_admin_handlers


def register_admins_handlers(dp: Dispatcher):
    register_admin_handlers(dp)
