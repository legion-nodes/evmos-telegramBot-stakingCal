from aiogram import types, Dispatcher
from aiogram.dispatcher import FSMContext
from aiogram.types import ChatType

from database.models import UserType


async def admin_command(message: types.Message, state: FSMContext):
    await state.reset_state()
    await message.answer("You are admin!")


def register_admin_handlers(dp: Dispatcher):
    # Default filters in all handlers
    defaults = {'chat_type': ChatType.PRIVATE, 'user_type': [UserType.admin], 'state': '*'}

    dp.register_message_handler(admin_command, commands=['admin'], **defaults)
